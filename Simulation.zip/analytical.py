import numpy as np
from parameters import c, length, nx, nt, dt
from conditions import u0, g, u0_vec


def u(t: float, x: float) -> float:
    """
    :param t: Time
    :param x: Position
    :return: Value of u at the time and position given
    """
    if x - c * t > 0:
        return u0(x - c * t) + 2 * x * t
    else:
        return g(t - x / c)


u_vec = np.vectorize(u, otypes=[float])


def get_analytical_solution() -> np.ndarray[float]:
    """
    :return: The analytical solution as U, matrix of shape (Nt, Nx) containing all the values for each time step
    """
    x = np.linspace(0, length, nx)

    u_mat = np.zeros((nt, nx))
    u_mat[0] = u0_vec(x)

    for n in range(nt - 1):
        u_mat[n + 1] = u_vec((n + 1) * dt, x)

    return u_mat
