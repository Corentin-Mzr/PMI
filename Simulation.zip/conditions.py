import numpy as np


def u0(x: float) -> float:
    """
    :param x: Position
    :return: Value of u when x - ct > 0
    """
    return np.exp(-x**2)


u0_vec = np.vectorize(u0, otypes=[float])


def g(t: float) -> float:
    """
    :param t: Time
    :return: Value of u when x - ct < 0
    """
    return 4 * np.abs(np.sin(5 * np.pi * t))


g_vec = np.vectorize(g, otypes=[float])


def f(t: float, x: float) -> float:
    """
    :param t: Time
    :param x: Position
    :return: Return the right-hand side of the equation for the time and position given
    """
    return 2


f_vec = np.vectorize(f, otypes=[float])
