import numpy as np

from numerical import get_numerical_solution
from analytical import get_analytical_solution
from display import show_as_image, show_as_animation


def main():
    # Change save_file to True if you want to save files
    # Change paths to avoid overwrite
    save_file = False
    path_1 = 'output/numerical_solution_validation_3.png'
    path_2 = 'output/analytical_solution_validation_3.png'
    path_3 = 'output/absolute_error_validation_3.png'
    
    # Numerical solution
    u_num = get_numerical_solution()
    show_as_image(u_num, title="Numerical solution", to_save=save_file, path=path_1)

    # Analytical solution
    u_ana = get_analytical_solution()
    show_as_image(u_ana, title="Analytical solution", to_save=save_file, path=path_2)

    # Error between the two models
    abs_error = np.abs(u_ana - u_num)
    show_as_image(abs_error, title="Absolute error", to_save=save_file, path=path_3)


if __name__ == "__main__":
    main()
