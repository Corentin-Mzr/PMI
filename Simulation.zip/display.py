import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from parameters import length, tf, dt, nt

matplotlib.use('TkAgg')


def show_as_image(u: np.ndarray[float], title: str = "", to_save: bool = False, path: str = "") -> None:
    """
    :param u: Array containing all the values of U at each position, for each time step
    :param title : Title of the plot
    :param to_save : True to save the figure as a PNG file
    :param path: path to the file
    :return: Display the matrix
    """
    plt.figure(figsize=(8, 6))
    plt.imshow(u, extent=(0, length, 0, tf), origin='lower', aspect='auto')
    plt.colorbar(label='u(t,x)')
    plt.title('Evolution of the solution for the transport equation in 1D (matrix form)\n'
              f'{title}')
    plt.xlabel('Position (x)')
    plt.ylabel('Time (t)')

    if to_save and path != "":
        plt.savefig(path)
    plt.show()


def show_as_animation(u: np.ndarray[float], title: str = "") -> None:
    """
    :param u: Array containing all the values of U at each position, for each time step
    :param title: Title of the plot
    :return: Create an animation by looping on each row of the matrix
    """
    fig, ax = plt.subplots()
    for n in range(0, nt):
        if not plt.fignum_exists(fig.number):
            plt.close(fig)
            break

        ax.cla()
        ax.axis((0, length, np.min(u), np.max(u)))
        plt.title(title)
        ax.plot(u[n])
        plt.pause(dt)

    if plt.fignum_exists(fig.number):
        plt.close()
