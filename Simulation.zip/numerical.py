import numpy as np
from parameters import c, dt, dx, nx, nt, length
from conditions import u0_vec, g_vec, f_vec


def get_numerical_solution() -> np.ndarray[float]:
    """
    :return: The numerical solution as U, matrix of shape (Nt, Nx) containing all the values for each time step
    """
    # Initialization of the space
    x = np.linspace(0, length, nx)

    # Computation of the matrix
    k = c * dt / dx
    a_mat = np.eye(nx) - k * (np.eye(nx, k=0) - np.eye(nx, k=-1))

    # Initialization of the matrix
    u = np.zeros((nt, nx))
    u[0] = u0_vec(x)

    # Scheme
    for n in range(nt - 1):
        u[n + 1] = a_mat.dot(u[n]) + dt * f_vec(n * dt, u[n])

        # Boundary conditions
        idx = np.where(x - c * n * dt < 0)[0]
        if len(idx) != 0:
            u[n + 1, idx] = g_vec(n * dt - x[idx] / c)

    return u
